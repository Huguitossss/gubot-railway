from launcher import start_bot
start_bot()