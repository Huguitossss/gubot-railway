
import discord
from discord import app_commands
from discord.ext import tasks
from flask import Flask, render_template, request
import threading
import requests
import datetime
import openai
import os
from dotenv import load_dotenv

def start_bot():
    load_dotenv()
    DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
    DISCORD_CANAL_ID = int(os.getenv("DISCORD_CANAL_ID"))
    DISCORD_TOKENS_CHANNEL_ID = int(os.getenv("DISCORD_TOKENS_CHANNEL_ID"))
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    openai.api_key = OPENAI_API_KEY

    app = Flask(__name__)

    @app.route("/")
    def index():
        return render_template("index.html")

    @app.route("/forcar-narrativa", methods=["POST"])
    def forcar_narrativa():
        tokens = buscar_tokens_populares()
        texto = gerar_narrativa(tokens)
        canal = client.get_channel(DISCORD_CANAL_ID)
        coro = canal.send(texto)
        fut = discord_client.loop.create_task(coro)
        return "Resumo enviado!"

    def run_painel():
        app.run(host="0.0.0.0", port=5000)

    def buscar_tokens_populares():
        try:
            data = requests.get("https://quote-api.jup.ag/v6/market-info").json()
            tokens = sorted(data.items(), key=lambda x: -x[1].get("liquidity", 0))[:5]
            return [f"{t[0]} ({t[1]['liquidity']:.2f} de liquidez)" for t in tokens]
        except:
            return ["Erro ao buscar tokens."]

    def gerar_narrativa(tokens):
        hoje = datetime.datetime.now(datetime.UTC).strftime("%d de %B de %Y")
        prompt = f"Resumo do ecossistema Solana no dia {hoje}, tokens em destaque: {', '.join(tokens)}"
        resposta = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}]
        )
        return resposta.choices[0].message.content.strip()

    intents = discord.Intents.default()
    intents.message_content = True
    client = discord.Client(intents=intents)
    discord_client = client
    tree = app_commands.CommandTree(client)

    @client.event
    async def on_ready():
        print(f"Gubot online como {client.user}")
        await tree.sync()
        verificar_tokens_promissores.start()

    @tree.command(name="ca", description="Verificar contrato de token")
    @app_commands.describe(endereco="Endereço do contrato (CA)")
    async def ca_command(interaction: discord.Interaction, endereco: str):
        await interaction.response.defer()
        resposta = f"🔍 Analisando contrato `{endereco}`...\n(Lógica em construção)"
        await interaction.followup.send(resposta)

    @tree.command(name="resumo", description="Gerar resumo do dia")
    async def resumo_command(interaction: discord.Interaction):
        await interaction.response.defer()
        tokens = buscar_tokens_populares()
        texto = gerar_narrativa(tokens)
        await interaction.followup.send(texto)

    @tasks.loop(minutes=3)
    async def verificar_tokens_promissores():
        try:
            data = requests.get("https://quote-api.jup.ag/v6/market-info").json()
            tokens_novos = sorted(data.items(), key=lambda x: x[1].get("created_at", 0), reverse=True)[:3]
            canal = client.get_channel(DISCORD_TOKENS_CHANNEL_ID)
            for t, info in tokens_novos:
                nome = info.get("name", "???")
                simbolo = info.get("symbol", "???")
                liq = info.get("liquidity", 0)
                vol = info.get("volume_24h", 0)
                if liq > 10000 and vol > 30000:
                    msg = f"💎 **Token Promissor Detectado**
🪙 `{nome}` (${simbolo})
💧 LP: ${liq:,.0f}
📈 Vol: ${vol:,.0f}"
                    await canal.send(msg)
        except Exception as e:
            print("Erro ao verificar tokens:", e)

    threading.Thread(target=run_painel).start()
    client.run(DISCORD_TOKEN)
