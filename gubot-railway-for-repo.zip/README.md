# Gubot Railway

Bot de narrativa e scanner de tokens stealth para Discord.

## 📦 Variáveis obrigatórias (.env)

- DISCORD_TOKEN
- DISCORD_CANAL_ID
- DISCORD_TOKENS_CHANNEL_ID
- OPENAI_API_KEY

## 🚀 Deploy no Railway

1. Crie este repositório no GitHub.
2. Vá para https://railway.app
3. Clique em "New Project" > "Deploy from GitHub"
4. Escolha este repositório
5. Vá em Settings > Variables e adicione as variáveis .env acima.
6. Pronto! O bot e o painel web iniciam automaticamente.
